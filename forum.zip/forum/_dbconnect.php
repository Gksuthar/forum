<?php
// include '_header.php';
$SERVERNAME = 'localhost';
$username = 'root';
$password = '';
$database = 'king';

$conn = mysqli_connect($SERVERNAME, $username, $password, $database);

if (!$conn) {
    die("We are fatching problem to connect database " . mysqli_connect_error());
}
else {
    
}



?>