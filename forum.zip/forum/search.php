<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<style>
    .col-md-4 {
        width: 100%;
        display: flex;
        justify-content: center;
    }
</style>

<body>
    <?php include '_header.php'; ?>
    <?php include '_dbconnect.php'; ?>
    <div class="container">

        <div class="jumbotron my-5">
            <h1>search result for <?php echo $_GET['search'] ?></h1>
            <div class="row">
                <?php
                $query = $_GET['search'];
                $sql = "SELECT * from threads where match (threads_title,threads_disc) against ('$query')";
                $result = mysqli_query($conn, $sql);
                $findRes = true;
                while ($row = mysqli_fetch_assoc($result)) {
                    $title = $row['threads_title'];
                    $disc  = $row['threads_disc'];

                    $sid = $row['threads_id'];
                    $rrr = "threadid.php?threadsid='.$sid.'";

                    $findRes = false;
                }
                ?>
                <p class="display-4"><?php echo $title; ?> </p>
                <p class="lead"><?php echo $disc; ?></p>
                <hr class="my-4">
                <p>This is pear shering konowdalge to each-other</p>
                <a class="btn btn-success btn-lg" href="#" role="button">Hello</a>
            

           <?php  
                if ($findRes == true) {
                    echo '<div class="jumbotron jumbotron-fluid my-4">
                    <div class="container my-4">
                        <h1 class="display-4">No result find</h1>
                        <p class="lead">being the first person to comment.</p>
                    </div>
                </div>';
                }
                ?>
            </div>
        </div>




    </div>

</body>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
</script>

</html>