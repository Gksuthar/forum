<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<style>
  .col-md-4 {
    width: 100%;
    display: flex;
    justify-content: center;
  }
</style>

<body>
  <?php include('_header.php'); ?>
  <?php include '_dbconnect.php';?>

  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active" style="height:400px;width:100%">
        <img class="d-block w-100" src="img2.jpg" alt="First slide" style="height:400px;width:100%">
      </div>
      <div class="carousel-item" style="height:400px;width:100%">
        <img class="d-block w-100" src="img3.jpg" alt="Second slide" style="height:400px;width:100%">
      </div>
      <div class="carousel-item" style="height:400px;width:100%">
        <img class="d-block w-100" src="img4.jpg" alt="Third slide" style="height:400px;width:100%">
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>

  <h1 style="text-align:center;">I-Conic</h1>
  <div class="row">

    <?php
    $sql = "SELECT *from categories";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_assoc($result)) {
      $cat = $row['categories_name'];
      $cat1 = $row['categories_disc'];
      $id = $row['categories_id'];

      echo '<div class="col-md-4 my-2">
        <div class="card" style="width: 18rem;">
          <img class="card-img-top" src="https://images.unsplash.com/photo-1671726805228-dc54c08408ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwzOTUyODV8MXwxfGFsbHwxfHx8fHx8Mnx8MTY3Mjc0NDgxNg&ixlib=rb-4.0.3&q=80&w=400" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title"> <a href ="threads.php?catid=' . $id . '">' . $cat . '</a></h5>
            <p class="card-text">' . substr($cat1, 0, 90), '....' . '.</p>
            <a href="#" class="btn btn-primary">Go somewhere</a>
          </div>
        </div>
      </div>';
    }
    ?>
  </div>



</body>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

</html>