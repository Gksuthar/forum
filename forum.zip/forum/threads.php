<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<style>
    .col-md-4 {
        width: 100%;
        display: flex;
        justify-content: center;
    }
</style>

<body>
    <?php include '_header.php';
    include '_dbconnect.php';
    $rid = $_GET['catid'];
    include 'signup.php';
    ?>


    <?php
    $showAlert = false;
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $title = $_POST['name'];
        $disc = $_POST['name_disc'];
        $sql = "INSERT INTO threads VALUES('','$title','$disc','$rid','0',current_timestamp())";
        $result = mysqli_query($conn, $sql);
        $showAlert = true;
        if ($showAlert) {
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Sucess!</strong> The Quation is Added secussfully!.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
                </button>
              </div>';
        }
    }
    ?>

    <!-- <h1 style="text-align:center;">I-Conic</h1> -->
    <div class="container my-4">
        <div class="jumbotron">
            <?php
            // $rid = $_GET['catid'];
            $rid = $_GET['catid'];
            $sql = "SELECT *FROM categories where categories_id = $rid";
            $result = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_assoc($result)) {
                $name = $row['categories_name'];
                $disc = $row['categories_disc'];
                $cat = $row['categories_name'];
                // $names = $row['categories_name'];
            }
            ?>
            <h1 class="display-4">Welcome to <?php echo $name; ?> forum</h1>
            <p class="lead"><?php echo $disc; ?></p>
            <hr class="my-4">
            <p>This is pear shering konowdalge to each-other</p>
            <a class="btn btn-success btn-lg" href="#" role="button">Learn more</a>
        </div>
    </div>
    <div class="container">
        <h1>Start a Discussion</h1>
        <!-- We are use to threding to quation sort  -->


        <form action="#" method="POST">

            <label for="exampleFormControlInput1" class="form-label">Enter the titile of Problem</label>
            <input type="text" class="form-control" id="exampleFormControlInput1" name="name" placeholder="Enter the title" required>
            <div class="mb-3">
                <label for="exampleFormControlTextarea1" class="form-label">Explain problem</label>
                <textarea class="form-control" id="exampleFormControlTextarea1" name="name_disc" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>

        </form>
    </div>

    <div class="container my-5">
        <h1> Quation-Answer</h1>

        <div class="container">

            <?php
            $rid = $_GET['catid'];
            $sql = "SELECT *from threads where threads_cat_id = $rid";
            $result = mysqli_query($conn, $sql);
            $noResult = true;
            while ($row = mysqli_fetch_assoc($result)) {
                $noResult = false;
                $title = $row['threads_title'];
                $desc = $row['threads_disc'];
                $tid = $row['threads_id'];
                $threads_user_id = $row['threads_user_id'];

                echo '<div class="media my-4">
               <img class="mr-3" src="images.png"height="35px" alt="Generic placeholder image">
               <div class="media-body">
               <h5 class="mt-0"><a href="threadid.php?threadsid=' . $tid . '">' . $title . '</a></h5>
               
               ' . $desc . '
               </div>
               </div>';
            }
            if ($noResult == true) {
                echo '<div class="jumbotron jumbotron-fluid">
                <div class="container">
                  <p class="display-4">No Threads Founds</p>
                  <p class="lead">be the first person to ask a Quation!.</p>
                </div>
              </div>';
            }
            ?>
        </div>
    </div>
</body>

</html>