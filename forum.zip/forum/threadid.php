<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<style>
    .col-md-4 {
        width: 100%;
        display: flex;
        justify-content: center;
    }
</style>

<body>
    <?php include '_header.php';
    include 'signup.php';
    include '_dbconnect.php';

    ?>
     <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        # code...
        // include '_dbconnect.php';
        $tit = $_POST['name_disc'];
        $id = $_GET['threadsid'];
        $sql = "INSERT INTO comments values('','$tit','$id','current_timestamp()')";
        $result = mysqli_query($conn, $sql);
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Sucess!</strong> Your comment is Added Secussfully.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>';
    }

    ?>



    <h1 style="text-align:center;">I-Conic</h1>
    <div class="container my-4">
        <div class="jumbotron">
            <?php
            $takeid = $_GET['threadsid'];
            $ids = "SELECT *from threads where threads_id=$takeid";
            $result = mysqli_query($conn, $ids);
            while ($row = mysqli_fetch_assoc($result)) {
                $name = $row['threads_title'];
                $disc = $row['threads_disc'];
            }

            ?>
            <h1 class="display-4"><?php echo $name; ?> </h1>
            <p class="lead"><?php echo $disc; ?></p>
            <hr class="my-4">
            <p>This is pear shering konowdalge to each-other</p>
            <a class="btn btn-success btn-lg" href="#" role="button">Learn more</a>
        </div>
    </div>

    <div class="container">
        <form action="#" method="post">
            <div class="mb-3">
                <label for="exampleFormControlTextarea1" class="form-label">Explain problem</label>
                <textarea class="form-control" id="exampleFormControlTextarea1" name="name_disc" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
   
    <div class="container">
        <h1>Discussion</h1>

        <div class="container">
            <?php
            // $sql = "SELECT *FROM comments";
            $id = $_GET['threadsid'];
            $sql = "SELECT *from comments where threads_id = $id";
            // $sql = "INSERT INTO comments values ('','$name_disc')";
            $result = mysqli_query($conn, $sql);
            $findRocord = true;
            while ($row = mysqli_fetch_assoc($result)) {
                $findRocord = false;
                $disc_id = $row['comment_id'];
                $disc_dsc = $row['comment_disc'];
                $comment_time = $row['comment_time'];
                // $threads_id = $row['threads_id'];
                echo '<div class="media my-4">
                <img class="mr-3" src="images.png"height="35px" alt="Generic placeholder image">
                <div class="media-body">
                <p class="mt-0 my-0"><a href="threadid.php?threadsid"></a>
                <p class="font-weight-bold my-0">~LUCIFER~</p>

                '. $disc_dsc . '</p>
                </div>
                </div>';
            }
            if ($findRocord == true) {

                echo '<div class="jumbotron jumbotron-fluid">
                <div class="container">
                  <p class="display-4">No Discussion Founds</p>
                  <p class="lead">be the first person to ask a Quation!.</p>
                </div>
              </div>';
            }








            ?>
        </div>

    </div>
</body>

</html>